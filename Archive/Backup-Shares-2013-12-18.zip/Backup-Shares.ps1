 <#
 .Synopsis
 Get Shared folders from current system and run a incremental or full backup to a specified server/device.
 .Description
 The destination server must have a shared folder that matches the name of the machine server running the script.
 The account running this script needs to have Modify/Change permissions on the dstServer share.
 .EXAMPLE
 backup-shares.ps1 -dstServer MrBackup
 LocalHost: MrServer
 Share on MrServer: StaffFiles
 Destination Server: MrBackup
 Run on Tuesday
 This will perform an incremental backup to \\MrServer\MrBackup\daily\Tuesday\StaffFiles
 .EXAMPLE
 backup-shares.ps1 -dstServer MrBackup -Full
 LocalHost: MrServer
 Share on MrServer: StaffFiles
 Destination Server: MrBackup
 Run with -Full switch included
 This will perform an incremental backup to \\MrServer\MrBackup\Weekly\StaffFiles
 .INPUTS
 -dstServer Servername
 .OUTPUTS
 Robocopy log files are generated
 .NOTES
 The account running this script needs to have Modify/Change permissions on the dstServer share.
 The Destination Server must have a shared folder that matches the name of the machine server running the script.
 .FUNCTIONALITY
 #>
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$dstServer,[Switch]$Full );CLS
# Variables
$exclusions = get-content ".\exclusions\$ENV:COMPUTERNAME-exclusions.txt"
# Set Backup Type
if ( $Full -eq $True )
{$type = "Full";$options = '"/MIR" "/W:0" "/R:0" "/NFL" "/NDL" "/XF desktop.ini" "/XD" "AutoBackup" "Daily" "/L"'} 
else 
{$type = $(Date).DayofWeek;$options = '"/S" "/M" "/W:0" "/R:0" "/NFL" "/NDL" "/XF" "desktop.ini" "/XD" "AutoBackup" "/L"'}
Foreach ( $result in ( Get-WmiObject -Class Win32_Share | where {($_.type -eq 0) -and ($exclusions -notcontains $_.name)} ) ) 
{ 
	$share = $result.name ; $share
	$src = $result.path
	$dst = "\\$dstServer\$ENV:COMPUTERNAME\$share\$type"
	$log = "/LOG:\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-to-$dstServer-$share-$type.log"
	if ( Test-Path "\\$dstServer\$ENV:COMPUTERNAME" ){ ROBOCOPY $src $dst $options $log }
	else 
	{ 
		$log = "\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-to-$dstServer-$share-ERROR.log"
		Add-Content -Path $log -Val "$dst path not found." 
	}
}