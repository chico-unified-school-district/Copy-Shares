# Run a incremental or full backup to a specified server/device.
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full,[Switch]$Test ) ; CLS
$cwd = Split-Path $MyInvocation.MyCommand.Path ; CD $cwd
if (!(Test-Path .\logs\$env:COMPUTERNAME )) { MD .\logs\$env:COMPUTERNAME } # Create Log Subfolder
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|" #; $jobs
$Global:emailObjArray = @()
$Global:Subject = "DO - $env:COMPUTERNAME Backup Report $((date).dayofweek) - Cooper"
# Functions
Function Report-Msg ($type = "[INFO]",$msg,$hue = "Green") {
	Write-Host "$(date) $type $msg" -ForeGroundColor $hue
	# Add-Content $logFile -Value "$(date) $type $msg"
	# $global:emailObjArray += New-Object PSObject -Prop @{ Date=$(date); Type=$type; Message=$msg }
	# if ( $type -eq "[ERROR]" ) { $global:Bcc = "servicedesk.chicousd.org" }
	} # End Report-Msg
"Begin Backup via Job File"
ForEach ( $result in $jobs ) {
	$srcPath = $result.srcPath
	$dstServer = $result.dstServer
	$dstShare = $result.dstShare
	$dstPath = "\\$dstServer\$dstShare"
	$excludeDirs = @($result.excludeDirs.split(",")) + @("Adobe Premiere Pro Preview Files","$RECYCLE.BIN","System Volume Information") # Setting /XD variables
	$excludeFiles = @($result.excludeFiles.split(",")) + @("*.log","*desktop.ini","*.db","*.crdownload") # Setting /XF variables
	if ( (Test-Path $srcPath) -and (Test-Path $dstPath) ) {
		if ( $Full -eq $True ){ "Full Backup" ; $type = "Full" ; $options = @("/MIR") } # Setting Full
		else { "Daily Backup" ; $type = $(Date).DayofWeek ; $options = @("/S", "/M") } # Setting Daily
		$dstPath = "\\$dstServer\$dstShare\$type\"+$($srcPath.split("\"))[-1] # Appends source folder name
		"Setting LogFile Path"
		$logFile = ".\logs\$env:COMPUTERNAME\$dstshare-to-$dstServer-$type-"+$(date).year+"-"+$(date).month+"-"+$(date).day+".log"
		if ( (Test-Path $dstpath) -and ($Type -ne "Full") ) { "Removing Prior Daily: $dstpath" ; Get-ChildItem -Path $dstPath -Recurse | Remove-Item -Force -WhatIf }
		if ( $Test -eq $True ) { $testSwtich = "/L";"Test Run...`n" } else { $testSwtich = $null } # Test run
		"Job Overview:`nSource: $srcPath | Destination: $dstPath`nOptions: $options`nExclude: $excludeDirs`n$excludeFiles"
		"Running Core Backup Command..."
		ROBOCOPY $srcPath $dstPath $options /XD $excludeDirs /XF $excludeFiles /LOG+:$logFile /W:0 /R:0 /NFL /NDL $testSwtich
		# Report-Msg
		}
	else { Report-Msg -type "[ERROR]" -msg "Problem with $srcPath or $dstPath" -hue Red }
	# "Press ENTER key to continue...";read-host
	} 
$emailObjArray
# \\gears\Support\Scripts\ps\Common\Send-HTMLEmail-02.ps1 $emailObjArray -Subject $Subject
# End Backup