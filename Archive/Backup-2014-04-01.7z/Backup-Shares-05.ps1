# Run a incremental or full backup to a specified server/device.
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full,[Switch]$Test ) ; CLS
$cwd = Split-Path $MyInvocation.MyCommand.Path ; CD $cwd
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|" #; $jobs
$Global:emailObjArray = @()
$Global:Subject = "DO - $env:COMPUTERNAME Backup Report $((date).dayofweek) - Cooper"
$BurnNotice = $True # If $True this will allow for the recursive deletion of the previous delta folder
# Functions
Function Report-Msg ($type = "[INFO]",$msg,$hue = "Green") {
	Write-Host "$(date) $type $msg" -ForeGroundColor $hue
	# Add-Content $logFile -Value "$(date) $type $msg"
	# $global:emailObjArray += New-Object PSObject -Prop @{ Date=$(date); Type=$type; Message=$msg }
	# if ( $type -eq "[ERROR]" ) { $global:Bcc = "servicedesk.chicousd.org" }
	} # End Report-Msg
# Begin Backup via Job File
ForEach ( $result in $jobs ) {
	$srcPath = $result.srcPath; $dstServer = $result.dstServer; $dstShare = $result.dstShare; $dstPath = "\\$dstServer\$dstShare" # Setting Src and Dst variables
	$excludeDirs = @($result.excludeDirs.split(",")) + @("*Temp","Adobe Premiere Pro Preview Files","$RECYCLE.BIN","System Volume Information") # Setting /XD variables
	$excludeFiles = @( $result.excludeFiles.split(",")) + @("*.tmp","*.log","*desktop.ini","*.db","*.crdownload") # Setting /XF variables
	if ( (Test-Path $srcPath) -and (Test-Path $dstPath) ) {
		if ( $Test -eq $True ) { $testSwtich = "/L";"Test Run...`n" } else { $testSwtich = $null } # If $true perform a test-run
		# Set Backup Type
		if ( $Full -eq $True ){ $type = "Full" ; $options = @("/MIR") } # Setting Full Type
		else { $type = $(Date).DayofWeek ; $options = @("/S", "/M") # Setting Daily Type
			if ( ( $BurnNotice -eq $True ) -and ( Test-Path $dstpath ) ) { # Delete Old Incremental Backups
				Get-ChildItem -Path "\\$dstServer\$dstShare\$type" -Recurse | Remove-Item -Force ; $BurnNotice = $False } 
			}
		$dstPath = "\\$dstServer\$dstShare\$type\"+$($srcPath.split("\"))[-1] # This appends the source folder name
		if (!(Test-Path .\logs\$env:COMPUTERNAME )) { MD .\logs\$env:COMPUTERNAME } # Create Log subfolder
		$logFile = ".\logs\$env:COMPUTERNAME\$dstshare-to-$dstServer-$type-"+$(date).year+"-"+$(date).month+"-"+$(date).day+".log"
		# Core Backup Command
		"Source: $srcPath | Destination: $dstPath`nOptions: $options`nExclude: $excludeDirs`n$excludeFiles"
		ROBOCOPY $srcPath $dstPath /B /W:0 /R:0 /NFL /NDL $options /XD $excludeDirs /XF $excludeFiles $testSwtich /LOG+:$logFile
		# Report-Msg
		}
	else { Report-Msg -type = "[ERROR]" $msg "$(date) [ERROR] Src: Dst: - Problem with Path:$srcPath or Path:$dstPath" -hue Red }
	# "Press ENTER key to continue...";read-host
	} 
$emailObjArray
# \\gears\Support\Scripts\ps\Common\Send-HTMLEmail-02.ps1 $emailObjArray -Subject $Subject
# End Backup