###################################################################
# Run an incremental or full backup to a specified server/device. #
###################################################################
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full,[Switch]$Test ) ; CLS
$cwd = Split-Path $MyInvocation.MyCommand.Path ; $cwd ; CD $cwd
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|" #; $jobs
$Global:emailObjArray = @()
$Global:Subject = "DO - $env:COMPUTERNAME Backup Report $((date).dayofweek) - Cooper"
# Functions
Function Report-Msg ($type = "[INFO]",$msg,$hue = "Green") {
	Write-Host "$(date) $type $msg" -ForeGroundColor $hue
	# Add-Content $logFile -Value "$(date) $type $msg"
	# $global:emailObjArray += New-Object PSObject -Prop @{ Date=$(date); Type=$type; Message=$msg }
	# if ( $type -eq "[ERROR]" ) { $global:Bcc = "servicedesk.chicousd.org" }
	} # End Report-Msg
Report-Msg -msg "Begin Backup via Job File"
ForEach ( $job in $jobs ) {
	$srcServer = $job.srcServer
	$srcShare = $job.srcShare
	$srcSharePath = "\\"+$srcServer+"\"+$srcShare
	$dstServer = $job.dstServer
	$dstShare = $job.dstShare
	$dstSharePath = "\\$dstServer\$dstShare"
	$excludeDirs = @($job.excludeDirs.split(",")) + @("Adobe Premiere Pro Preview Files","$RECYCLE.BIN","System Volume Information") # Setting /XD variables
	$excludeFiles = @($job.excludeFiles.split(",")) + @("*.log","*desktop.ini","*.db","*.crdownload") # Setting /XF variables
	if (!(Test-Path $srcSharePath)) {Report-Msg -type "[ERROR]" -msg "Problem with $srcSharePath" -hue Red}
	elseif (!(Test-Path $dstSharePath )) {Report-Msg -type "[ERROR]" -msg "Problem with $dstSharePath" -hue Red}
	else {
		if ( $Full -eq $True ){Report-Msg -Msg "Full Backup" ; $type = "Full" ; $options = @("/MIR") } # Setting Full
		else { Report-Msg -Msg "Daily Backup" ; $type = $(Date).DayofWeek ; $options = @("/S", "/M") } # Setting Daily
		$dstPath = "\\$dstServer\$dstShare\$type\$srcShare"
		if (!(Test-Path .\logs\$srcServer )) { MD .\logs\$srcServer } # Create Log Subfolder
		$logFile = ".\logs\$srcServer\$srcShare-to-$dstServer-$type-"+$(date).year+"-"+$(date).month+"-"+$(date).day+".log"
		if ( (Test-Path $dstpath) -and ($Type -ne "Full") ) {
			Report-Msg -msg "Removing Prior Daily: $dstpath" -Hue Blue
			Get-ChildItem -Path $dstPath -Recurse | Remove-Item -Force -WhatIf
			}
		if ( $Test -eq $True ) { $testSwtich = "/L";Report-Msg -Msg "Test Run..." -Hue Yellow} else { $testSwtich = $null } # Test run
		Report-Msg -msg "Job Overview:`nSource: $srcSharePath`nDestination: $dstPath`nOptions: $options" -Hue Gray
		Report-Msg -msg "Running Core Backup Command..."
		ROBOCOPY $srcSharePath $dstPath $options /XD $excludeDirs /XF $excludeFiles /LOG+:$logFile /W:0 /R:0 /NFL /NDL $testSwtich
		}
	# "Press ENTER key to continue...";read-host
	}
# $emailObjArray
# \\gears\Support\Scripts\ps\Common\Send-HTMLEmail-02.ps1 $emailObjArray -Subject $Subject
# End Backup Script