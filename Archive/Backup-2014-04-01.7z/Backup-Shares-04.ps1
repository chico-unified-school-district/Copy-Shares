# Run a incremental or full backup to a specified server/device.
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full,[Switch]$Test );CLS
$cwd = Split-Path $MyInvocation.MyCommand.Path;CD $cwd
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|" # ; $jobs
$Global:emailObjArray = @()
$Global:Subject = "DO - $env:COMPUTERNAME Backup Report $((date).dayofweek) - Cooper"
$BurnNotice = $True # If $True this will allow for the recursive deletion of today's delta folder
# Functions
	function Report-Msg ($type = "[INFO]",$msg,$hue = "Green") {
		Write-Host "$(date) $type $msg" -ForeGroundColor $hue
		Add-Content $logFile -Value "$(date) $type $msg"
		$global:emailObjArray += New-Object PSObject -Prop @{ Date=$(date); Type=$type; Message=$msg }
		if ( $type -eq "[ERROR]" ) { $global:Bcc = "servicedesk.chicousd.org" }
		} # End Report-Msg
# Begin Backup via Job File
Foreach ( $result in $jobs ) {
	$excludeDirs = $null; $excludeFiles = $null # Clearing exclude variables
	$srcPath = $result.srcPath; $dstServer = $result.dstServer; $dstShare = $result.dstShare; $dstPath = "\\$dstServer\$dstShare" # Setting Src and Dst variables
	if ( $result.excludeDirs -ne $null ) { foreach ( $item in $result.excludeDirs.split(",") ){$excludeDirs = $excludeDirs+'"'+$item+'" '} } # Setting /XD variables
	if ( $result.excludeFiles -ne $null ) { foreach ( $item in $result.excludeFiles.split(",") ){$excludeFiles = $excludeFiles+'"'+$item+'" '} }  # Setting /XF variables
	if ( (Test-Path $srcPath) -and (Test-Path $dstPath) ) {
		if ( $Test -eq $True ) { $testSwtich = "/L";"Test Run...`n" } Else { $testSwtich = $null } # If $true perform a test-run
		# Set Backup Type
		if ( $Full -eq $True ){ $type = "Full" ; $options = @("/MIR") } # Setting Full Type
		else { $type = $(Date).DayofWeek ; $options = @("/S", "/M") # Setting Daily Type
			if ( ( $BurnNotice -eq $True ) -and ( Test-Path $dstpath ) ) { Get-ChildItem -Path "\\$dstServer\$dstShare\$type" -Recurse | Remove-Item -Recurse -Force ; $BurnNotice = $False } # Delete Old Incremental Backups
			}
		$dstPath = "\\$dstServer\$dstShare\$type\"+$($srcPath.split("\"))[-1] # This appends the Source folder name
		$logFile = "\\gears\Support\Scripts\Servers\Backup\logs\$dstshare-to-$dstServer-$type-"+$(date).year+"-"+$(date).month+"-"+$(date).day+".log"
		# Core Backup Command
		"Source: $srcPath`nDestination: $dstPath`nOptions: $options`nexDirs: $excludeDirs`nexFiles: $excludeFiles"
		ROBOCOPY $srcPath $dstPath /B /W:0 /R:0 /NFL /NDL $options /XD $excludeDirs /XF $excludeFiles $testSwtich /LOG+:$logFile
		# Report-Msg
		}
	else { Report-Msg -type = "[ERROR]" $msg "$(date) [ERROR] Src: Dst: - Problem with Path:$srcPath or Path:$dstPath" -hue "Red" }
	# "Press ENTER key to continue...";read-host
	
	} 
$emailObjArray
# \\gears\Support\Scripts\ps\Common\Send-HTMLEmail-02.ps1 $emailObjArray -Subject $Subject
# End Backup