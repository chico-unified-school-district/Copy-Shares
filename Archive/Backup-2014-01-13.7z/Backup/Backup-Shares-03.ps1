# Run a incremental or full backup to a specified server/device.
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full,[Switch]$Test );CLS
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|"
# $jobs
# Parse Job File
Foreach ( $result in $jobs ) 
{ 
	$excludeDirs = $null;$excludeFiles = $null
	$srcPath = $result.srcPath;$dstServer = $result.dstServer;$dstShare = $result.dstShare;$dstPath = "\\$dstServer\$dstShare"
	if ( $result.excludeDirs -ne $null ) { foreach ( $item in $result.excludeDirs.split(",") ){$excludeDirs = $excludeDirs+'"'+$item+'" '} }
	if ( $result.excludeFiles -ne $null ) { foreach ( $item in $result.excludeFiles.split(",") ){$excludeFiles = $excludeFiles+'"'+$item+'" '} }
	# "Press ENTER key to continue...";read-host
	if ( (Test-Path $srcPath) -and (Test-Path $dstPath) )
	{
		if ( $Test -eq $True ) {$testSwtich = "/L";"Test Run...`n"} Else {$testSwtich = $null}
		# Set Backup Type
		if ( $Full -eq $True ){$type = "Full";$options = "/MIR"} 
		else {$type = $(Date).DayofWeek;$options = "/S /M"}
		$dstPath = "\\$dstServer\$dstShare\$type"
		$logFile = "\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-$dstshare-to-$dstServer-$type.log"
		# Delete Old Incremental Backups
		IF ( ($type -ne "Full") -and (Test-Path $dstpath) ) {Remove-Item $dstpath -Recurse -Force -Whatif}
		# Core Backup Command
		"Source: $srcPath`nDestination: $dstPath`nOptions: $options`nexDirs: $excludeDirs`nexFiles: $excludeFiles"
		ROBOCOPY $srcPath $dstPath /W:0 /R:0 /NFL /NDL $options /XD $excludeDirs /XF $excludeFiles $testSwtich /LOG:$logFile
	}
	else 
	{ 
		$errorLog = "\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-$dstshare-to-$dstServer-$type-ERROR.log"
		Add-Content -Path $errorLog -Val "$(date) [ERROR] Problem with Path:$srcPath or Path:$dstPath"
	}
	# "Press ENTER key to continue...";read-host
}