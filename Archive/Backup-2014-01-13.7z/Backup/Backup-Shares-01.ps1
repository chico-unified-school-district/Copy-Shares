 <#
 .Synopsis
 Get Shared folders from current system and run a incremental or full backup to a specified server/device.
 .Description
 The destination server must have a shared folder that matches the name of the machine server running the script.
 The account running this script needs to have Modify/Change permissions on the dstServer share.
 .EXAMPLE
 backup-shares.ps1 -dstServer MrBackup
 LocalHost: MrServer
 Share on MrServer: StaffFiles
 Destination Server: MrBackup
 Run on Tuesday
 This will perform an incremental backup to \\MrServer\MrBackup\daily\Tuesday\StaffFiles
 .EXAMPLE
 backup-shares.ps1 -dstServer MrBackup -Full
 LocalHost: MrServer
 Share on MrServer: StaffFiles
 Destination Server: MrBackup
 Run with -Full switch included
 This will perform an incremental backup to \\MrServer\MrBackup\Weekly\StaffFiles
 .INPUTS
 -dstServer Servername
 .OUTPUTS
 Robocopy log files are generated
 .NOTES
 The account running this script needs to have Modify/Change permissions on the dstServer share.
 The Destination Server must have a shared folder that matches the name of the machine server running the script.
 .FUNCTIONALITY
 #>
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full );CLS
# Variables
$jobs = Import-Csv $jobFile
# Set Backup Type
if ( $Full -eq $True )
{
	$type = "Full"
	# $options = '"/MIR" "/W:0" "/R:0" "/NFL" "/NDL" "/XF" "desktop.ini" "/XD" "AutoBackup" "/L"'
	$options = '"/MIR" "/W:0" "/R:0" "/NFL" "/NDL" "/XF" "desktop.ini" "/XD" "AutoBackup"'
} 
else 
{
	$type = $(Date).DayofWeek
	$options = '"/S" "/M" "/W:0" "/R:0" "/NFL" "/NDL" "/XF" "desktop.ini" "/XD" "AutoBackup" "/L"'
	# $options = '"/S" "/M" "/W:0" "/R:0" "/NFL" "/NDL" "/XF" "desktop.ini" "/XD" "AutoBackup"'
}
Foreach ( $result in $jobs ) 
{ 
	$srcPath = $result.srcPath
	$dstServer = $result.dstServer
	$dstShare = $result.dstShare
	$dstPath = "\\$dstServer\$dstShare"
	$fullDst = "$dstPath\$dstShare\Daily\$type"
	$fullDst
	$log = "/LOG:\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-$dstServer-$dstshare-backup-$type.log"
	if ( (Test-Path $srcPath) -and (Test-Path $dstPath) ) 
	{
		IF ($type -ne "Full") {Remove-Item $fullDst -Recurse -Force -Whatif}
		ROBOCOPY $srcPath $fullDst $options $log
	}
	else 
	{ 
		$log = "\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-$dstServer-$dstShare-backup-$type-ERROR.log"
		Add-Content -Path $log -Val "$(date) [ERROR] Problem with $src or $dst" 
	}
	# "Any key to continue..."
	# read-host
}