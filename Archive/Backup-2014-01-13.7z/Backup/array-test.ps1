Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile);cls
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|"
# $jobs
# Parse Job File
Foreach ( $result in $jobs[0] )
{
	if ( $result.excludeDirs -ne $null ) 
	{
		foreach ( $item in $result.excludeDirs.split(",") ){$excludeDirs = $excludeDirs+'"'+$item+'" '}
		$excludeDirs = "/XD "+$excludeDirs
		$excludeDirs
	} else {$excludeDirs = $null}
}