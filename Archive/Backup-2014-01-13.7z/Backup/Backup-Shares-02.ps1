# Run a incremental or full backup to a specified server/device.
Param( [Parameter(Mandatory=$True)][ValidateNotNull()]$jobFile,[Switch]$Full,[Switch]$Test);CLS
# Variables
$jobs = Import-Csv $jobFile -Delimiter "|"
$jobs
# Parse Job File
Foreach ( $result in $jobs ) 
{ 
	$srcPath = $result.srcPath
	$dstServer = $result.dstServer
	$dstShare = $result.dstShare
	$dstPath = "\\$dstServer\$dstShare"
	if ( $result.excludeDirs -ne $null) {$excludeDirs = '"/XD" "'+$result.excludeDirs+'"';$excludeDirs} else {$excludeDirs = $null}
	$excludeDirs
	if ( $result.excludeDirs -ne $null) {$excludeFiles = '"/XF" "'+$result.excludeFiles+'"';$excludeFiles} else {$excludeFiles = $null}
	$excludeFiles
	read-host
	if ( (Test-Path $srcPath) -and (Test-Path $dstPath) ) 
	{
		if ( $Test -eq $True ) {$testSwtich = '"/L"';"Test Run...`n"} Else {$testSwtich = $null}
		# Set Backup Type
		if ( $Full -eq $True )
		{
			$type = "Full"
			$options = '"/MIR" "/W:0" "/R:0" "/NFL" "/NDL"' 
		} 
		else 
		{
			$type = $(Date).DayofWeek
			$options = '"/S" "/M" "/W:0" "/R:0" "/NFL" "/NDL"'
		}
		$dstPath = "\\$dstServer\$dstShare\$type"
		$log = "/LOG:\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-$dstshare-to-$dstServer-$type.log"
		# Delete Old Incremental Backups
		IF ( ($type -ne "Full") -and (Test-Path $dstpath) ) {Remove-Item $dstpath -Recurse -Force -Whatif}
		# Core Backup Command
		"Source: $srcPath`nDestination: $dstPath`nOptions: $options"
		"ROBOCOPY $srcPath $dstPath $options $log $excludeDirs $excludeFiles $testSwtich"
	}
	else 
	{ 
		$log = "\\gears\Support\Scripts\Servers\Backup\logs\$ENV:COMPUTERNAME-$dstshare-to-$dstServer-$type-ERROR.log"
		Add-Content -Path $log -Val "$(date) [ERROR] Problem with Path:$srcPath or Path:$dstPath"
	}
	# "Press ENTER key to continue...";read-host
}